# AWS DevOps Workshop

This workshop will guide you to build and deploy a sample JAVA Web Application hosted on Apache Tomcat Web Server through AWS CI/CD tools including CloudFormation, CodeBuild, CodeDeploy, and CodePipeline.
